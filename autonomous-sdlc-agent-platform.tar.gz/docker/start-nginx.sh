#!/bin/sh

# Start nginx in the foreground
exec nginx -g "daemon off;"